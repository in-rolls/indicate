﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HindiTransApp
{
    class ExceptionDictionary
    {
        static String[] IGNORE_LIST = 
        {
            "",
            "okMZ",
            "ि",
            "*+*",
            "OE "
        };

        List<StringException> exceptions;
        public ExceptionDictionary(string filename)
        {
            exceptions = new List<StringException>();
            StreamReader sr = new StreamReader(filename, Encoding.Default);
            string str;
            while ((str = sr.ReadLine()) != null)
            {
                string[] tokens = str.Split(new string[1] {"|rsm|"}, StringSplitOptions.RemoveEmptyEntries);
                StringException se = new StringException();
                se.ExceptionStr = tokens[0];
                se.FixStr = tokens[1];

                if (tokens.Length > 2)
                    se.FollowStr = tokens[2];
                else
                    se.FollowStr = "";

                exceptions.Add(se);
            }
            sr.Close();
        }

        public string fix(string line)
        {
            foreach (StringException se in exceptions)
            {
                if (se.FollowStr.Length > 0)
                {
                    int idx = line.IndexOf(se.ExceptionStr);
                    if (idx >= 0)
                    {
                        if (line.Length >= idx + se.ExceptionStr.Length + se.FollowStr.Length)
                        {
                            idx = line.IndexOf(se.FollowStr, idx + se.ExceptionStr.Length, se.FollowStr.Length, StringComparison.CurrentCulture);
                            if (idx >= 0)
                                line = line.Replace(se.ExceptionStr, se.FixStr);
                        }
                    }
                }
                else
                    line = line.Replace(se.ExceptionStr, se.FixStr); 
            }

            return line;
        }

        public static bool doIgnore(String check)
        {
            return IGNORE_LIST.Contains(check);
        }
    }
}
