﻿namespace HindiTransApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.parseFileButton = new System.Windows.Forms.Button();
            this.parseFileTextBox = new System.Windows.Forms.TextBox();
            this.parseFilesButton = new System.Windows.Forms.Button();
            this.parseFilesTextBox = new System.Windows.Forms.TextBox();
            this.infoTextBox = new System.Windows.Forms.TextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // parseFileButton
            // 
            this.parseFileButton.Location = new System.Drawing.Point(12, 38);
            this.parseFileButton.Name = "parseFileButton";
            this.parseFileButton.Size = new System.Drawing.Size(100, 26);
            this.parseFileButton.TabIndex = 0;
            this.parseFileButton.Text = "Parse File";
            this.parseFileButton.UseVisualStyleBackColor = true;
            this.parseFileButton.Click += new System.EventHandler(this.parseFileButton_Click);
            // 
            // parseFileTextBox
            // 
            this.parseFileTextBox.Location = new System.Drawing.Point(12, 12);
            this.parseFileTextBox.Name = "parseFileTextBox";
            this.parseFileTextBox.Size = new System.Drawing.Size(260, 20);
            this.parseFileTextBox.TabIndex = 1;
            // 
            // parseFilesButton
            // 
            this.parseFilesButton.Location = new System.Drawing.Point(12, 113);
            this.parseFilesButton.Name = "parseFilesButton";
            this.parseFilesButton.Size = new System.Drawing.Size(125, 23);
            this.parseFilesButton.TabIndex = 2;
            this.parseFilesButton.Text = "Parse Files";
            this.parseFilesButton.UseVisualStyleBackColor = true;
            this.parseFilesButton.Click += new System.EventHandler(this.parseFilesButton_Click);
            // 
            // parseFilesTextBox
            // 
            this.parseFilesTextBox.Location = new System.Drawing.Point(12, 87);
            this.parseFilesTextBox.Name = "parseFilesTextBox";
            this.parseFilesTextBox.Size = new System.Drawing.Size(260, 20);
            this.parseFilesTextBox.TabIndex = 3;
            // 
            // infoTextBox
            // 
            this.infoTextBox.Location = new System.Drawing.Point(12, 142);
            this.infoTextBox.Multiline = true;
            this.infoTextBox.Name = "infoTextBox";
            this.infoTextBox.Size = new System.Drawing.Size(260, 108);
            this.infoTextBox.TabIndex = 4;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(12, 256);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScrollBarsEnabled = false;
            this.webBrowser1.Size = new System.Drawing.Size(259, 20);
            this.webBrowser1.TabIndex = 5;
            this.webBrowser1.Visible = false;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 288);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.infoTextBox);
            this.Controls.Add(this.parseFilesTextBox);
            this.Controls.Add(this.parseFilesButton);
            this.Controls.Add(this.parseFileTextBox);
            this.Controls.Add(this.parseFileButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button parseFileButton;
        private System.Windows.Forms.TextBox parseFileTextBox;
        private System.Windows.Forms.Button parseFilesButton;
        private System.Windows.Forms.TextBox parseFilesTextBox;
        private System.Windows.Forms.TextBox infoTextBox;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}

