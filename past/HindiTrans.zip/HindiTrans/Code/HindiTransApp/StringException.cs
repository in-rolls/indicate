﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HindiTransApp
{
    class StringException
    {
        string exception;

        public string ExceptionStr
        {
            get { return exception; }
            set { exception = value; }
        }
        string fix;

        public string FixStr
        {
            get { return fix; }
            set { fix = value; }
        }
        string follow;

        public string FollowStr
        {
            get { return follow; }
            set { follow = value; }
        }
    }
}
