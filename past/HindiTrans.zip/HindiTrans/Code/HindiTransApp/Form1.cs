﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Net;
using Excel = Microsoft.Office.Interop.Excel;
using Gapi.Language;
using Gapi.Core;
using HTML;

namespace HindiTransApp
{
    public partial class Form1 : Form
    {
        //Boolean to determine if initial loading is complete
        bool wbDocLoaded = false;
        ExceptionDictionary ed_post;
        ExceptionDictionary ed_pre;

        int BUFFER_LIMIT = 250;

        public Form1()
        {
            InitializeComponent();
            webBrowser1.Navigate(@Directory.GetCurrentDirectory() + "\\converter_suchi.html");
            //webBrowser1.Navigate(@Directory.GetCurrentDirectory() + "\\converter_.html");
            ed_post = new ExceptionDictionary("exceptionlist.txt");
            ed_pre = new ExceptionDictionary("pre_exceptionlist.txt");

            /*String test = "4 | | 1074 | | Zia ul Husun Maqbool Husun | | Purush | | 28 | | Anarkshit | | Indian National Kangers | | Hath | | * O * $ end $ 473 | | 5 | | 4658 | | Nirottm | | sand Lal | | Purush | | 36 | | æ da group Pic | | Nirdliyr | | Almar $ end $ | | 193 | | 6 | | 3614 | | Lilavati | | Rajesh | | Women | | 38 | | Women | | Nirdliyr | | $ end Ptng $ | | 9 | | * O *";
            String[] tmp = test.Split(new string[] { "end $", "$ end" }, StringSplitOptions.RemoveEmptyEntries);
            int blah = 0;*/

        }

        private void parseFileButton_Click(object sender, EventArgs e)
        {
            if (!wbDocLoaded)
            {
                infoTextBox.AppendText("Waiting on javascript to initialize ... \n");
                while (!wbDocLoaded)
                {
                    System.Threading.Thread.Sleep(100);
                }
            }

            //DirectoryInfo di = new DirectoryInfo(parseFileTextBox.Text);
            //FileInfo[] rgFiles = di.GetFiles("*.aspx");
            //foreach (FileInfo fi in rgFiles)
            //{

            String filepath = parseFileTextBox.Text;
            filepath = (filepath.Equals("")) ? "test.txt" : filepath;

            String fileout = filepath.Substring(0, filepath.Length - 4) + ".out";

            infoTextBox.AppendText("Processing file: " + filepath + "\n");
            writeOutFile(filepath, fileout);

            //Call excel sheet generator
            createXLS(fileout);
        }

        private void parseFilesButton_Click(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(parseFilesTextBox.Text);
            FileInfo[] rgFiles = di.GetFiles("*.txt");
            foreach (FileInfo fi in rgFiles)
            {
                String filepath = fi.FullName;
                String fileout = filepath.Substring(0, filepath.Length - 4) + ".out";

                infoTextBox.AppendText("Processing file: " + filepath + "\n");

                //Generate .out file
                writeOutFile(filepath, fileout);

                //Call excel sheet generator
                createXLS(fileout);
            }
        }

        private void createXLS(String filename)
        {
            //Generate Excel file
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            Excel.Worksheet xlWorkSheet1;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Add(misValue);

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            xlWorkSheet1 = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(2);

            String filepath = filename;
            filepath = (filepath == null) ? "test.utxt" : filepath;

            //Write a line of data to it
            StreamReader sr = new StreamReader(filepath, Encoding.Unicode);

            ////System.Console.WriteLine("{0}", Translator.Translate("समाजवादी पार्टी", Language.Hindi, Language.English));
            String str = Translator.Translate(sr.ReadLine(), Language.Hindi, Language.English);
            int row = 1;

            //Setup header row
            xlWorkSheet.Cells[row, 1] = "Page";
            xlWorkSheet.Cells[row, 4] = "Name";
            xlWorkSheet.Cells[row, 5] = "Father/Husband's Name";
            xlWorkSheet.Cells[row, 6] = "Gender";
            xlWorkSheet.Cells[row, 7] = "Age";
            xlWorkSheet.Cells[row, 8] = "Caste";
            xlWorkSheet.Cells[row, 9] = "Party";
            xlWorkSheet.Cells[row, 10] = "Symbol";
            xlWorkSheet.Cells[row, 11] = "Votes Received";

            xlWorkSheet1.Cells[row, 1] = "Page";
            xlWorkSheet1.Cells[row, 4] = "Name";
            xlWorkSheet1.Cells[row, 5] = "Father/Husband's Name";
            xlWorkSheet1.Cells[row, 6] = "Gender";
            xlWorkSheet1.Cells[row, 7] = "Age";
            xlWorkSheet1.Cells[row, 8] = "Caste";
            xlWorkSheet1.Cells[row, 9] = "Party";
            xlWorkSheet1.Cells[row, 10] = "Symbol";
            xlWorkSheet1.Cells[row, 11] = "Votes Received";//*/

            row++;

            System.Console.WriteLine("Starting transliteration ...");

            //Initialize a carryover string
            //Useful when you need to read further into
            //the stream to ensure things are good
            string carryover = "";
            int co_count = 0;

            //For page counting
            bool pageEnd = false ;
            int page = 1;

            //Buffer to hold the entries before
            //feeding to the google translation/transliteration
            //Helps with bringing in less complaints
            String buffer = "";

            while (str != null)
            {
                string r = carryover;
                for (int i = 1 + co_count; i <= 10; i++)
                {
                    do
                    {
                        str = sr.ReadLine();
                        if (str != null && str.Equals("*-*"))
                        {
                            //if (i == 1)
                                //row++;

                            pageEnd = true;
                            //Did we come to an abrupt end ...
                            if (i > 1)
                                r += "||" + "*O*";
                            //break to take care of page end
                            //stuff
                            break;
                        }
                        //The e-ki-matra gets added on a separate
                        //line for some reason
                        else if (str != null && str.Equals("ि"))
                        {
                            r += "i";
                        }

                    } while (str != null && (ExceptionDictionary.doIgnore(str)));

                    if (pageEnd)
                        break;

                    if (str == null || str.Equals("-1") || (i > 1 && str.Equals("*-*")))
                        break;

                    bool r_update = false;
                    //Take care of exceptions
                    /* Exception Case 1:
                     * If we are at the 2nd column, occasionally
                     * the pdf-to-text conversion will concatenate
                     * both the id and the name
                     * 
                     * Solution:
                     * Split them and move on
                     * */
                    if (i == 2)
                    {
                        int tmp;
                        if (!Int32.TryParse(str, out tmp))
                        {
                            string[] tokens = str.Split(new char[1] { ' ' });
                            r += "||" + tokens[0];
                            i++;
                            str = "";
                            for (int x = 1; x < tokens.Length; x++)
                                str += tokens[x];
                        }
                    }
                    /* Exception Case 2:
                     * If we are at the 10th and final column
                     * the pdf-to-text conversion or due to the
                     * lack of information in the actual pdf document
                     * will cause this entry to actually be the first
                     * entry of the new row
                     * 
                     * Solution:
                     * Move ahead in the stream and check if the next
                     * 2 entries are numbers, implying the information
                     * for the new row is complete. If not, we are 
                     * already at a new row so adjust with the carryover
                     * */
                    else if (i == 10)
                    {
                        int tmp;
                        if (Int32.TryParse(str, out tmp))
                        {
                            string str1 = sr.ReadLine();
                            if (str1.Equals("*-*"))
                            {
                                r += "||" + str;
                                pageEnd = true;
                                break;
                            }
                            string str2 = sr.ReadLine();
                            if (Int32.TryParse(str1, out tmp) && Int32.TryParse(str2, out tmp))
                            {
                                r += "||" + str;
                                carryover = str1 + "||" + str2;
                                co_count = 2;
                            }
                            else
                            {
                                //Flag it since we missed one entry
                                r += "||" + "*O*";
                                carryover = str + "||" + str1 + "||" + str2;
                                co_count = 3;
                            }
                            break;
                        }
                    }
                    /* Exception Case 3:
                     * If we are at the 6th column
                     * the pdf-to-text conversion will occasionally
                     * divide the age into 2 seperate numbers
                     * 
                     * Solution:
                     * Move ahead in the stream and check if the next
                     * entry is a number and both numbers are single digit, 
                     * implying the information we have an exception. Combine
                     * the two digits into one number
                     * */
                    else if (i == 6)
                    {
                        if (str.Length == 1)
                        {
                            int tmp1;
                            int tmp2;
                            if (Int32.TryParse(str, out tmp1))
                            {
                                string str1 = sr.ReadLine();
                                if (Int32.TryParse(str1, out tmp2))
                                {
                                    //We have the exception
                                    if (tmp1 < 10)
                                        str += str1;

                                    //i--;
                                }
                                else
                                {
                                    //Just read another "good" entry
                                    str += "||" + str1;
                                    i++;
                                }
                            }
                            //Else something went wrong?
                            //else
                        }
                    }
                    /* Exception Case 4:
                     * This is a simple case to catch when something has
                     * gone wrong. If we ever find a number in the wrong
                     * column, some alignment has gone wrong.
                     * Solution:
                     * Flag the row and move on.
                     * */
                    else if (!(i == 1 || i == 6 || i == 10))
                    {
                        int tmp;
                        if (Int32.TryParse(str, out tmp))
                        {
                            string str1 = sr.ReadLine();
                            
                            if (str1.Equals("*-*"))
                            {
                                r += "||" + str + "||" + "*O*";
                                pageEnd = true;
                                break;
                            }

                            if (Int32.TryParse(str1, out tmp))
                            {
                                r += "||" + "*O*";
                                carryover = str + "||" + str1;
                                co_count = 2;
                                break;
                            }
                            else
                            {
                                i ++;
                                r += "||" + str + " *O*" + "||" + str1;
                                r_update = true;
                            }
                        }
                    }

                    if (!r_update)
                        r += "||" + str;

                    co_count = 0;
                    carryover = "";
                }

                if (r.Equals("") && !pageEnd)
                    break;

                if (pageEnd)
                {
                    if (buffer.Length + r.Length > BUFFER_LIMIT)
                    {
                        row = writeToExcel(buffer, xlWorkSheet, xlWorkSheet1, row, page);
                        row = writeToExcel(r, xlWorkSheet, xlWorkSheet1, row, page);
                    }
                    else
                    {
                        row = writeToExcel(buffer + r, xlWorkSheet, xlWorkSheet1, row, page);
                    }
                    buffer = "";
                    row++;
                    pageEnd = false;
                    page++;
                }
                else if (buffer.Length + r.Length > BUFFER_LIMIT)
                {
                    /*string[] rowStr = buffer.Split("\n".ToCharArray());
                    foreach (String r1 in rowStr)
                    {
                        if (r1.Length > 1)
                        {
                            r1 = ed_pre.fix(r1);
                            r1 = GetGoogleTranslation(r1, "en");
                            r1 = ed_post.fix(r1);
                            string[] cellStr = r1.Split("||".ToCharArray());
                            int j = 1;
                            xlWorkSheet.Cells[row, j] = page + "";
                            j++;
                            for (int c = 0; c < cellStr.Length && j <= 11; c++)
                            {
                                if (cellStr[c].Equals("*-*"))
                                    break;

                                if (!cellStr[c].Equals(""))
                                {
                                    xlWorkSheet.Cells[row, j] = cellStr[c];
                                    j++;
                                }
                            }
                        }
                    }*/
                    row = writeToExcel(buffer, xlWorkSheet, xlWorkSheet1, row, page);
                    buffer = r + "$end$";
                }
                else
                {
                    buffer += r + "$end$";
                }

                //infoTextBox.AppendText("Reading row " + row + "... \n");
                    //row++;
            }

            String fileout = filepath.Substring(0, filepath.Length - 4) + ".xls";
            
            //Check if we have an absolute filepath
            if (!filepath.Contains(":\\"))
                fileout = Directory.GetCurrentDirectory() + "\\" + fileout; 

            xlWorkBook.SaveAs(fileout, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);
            sr.Close();
        }


        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private String convertToUnicode(String str)
        {
            object[] args = { str };
            object t = webBrowser1.Document.InvokeScript("convert_to_unicode", args);
            t = webBrowser1.Document.GetElementById("unicode_text").GetAttribute("value");
            if (t != null)
                return t.ToString();

            return "";
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            object[] args = { "Test conversion: Õ " };
            object t = webBrowser1.Document.InvokeScript("convert_to_unicode", args);
            if (t != null)
            {
                infoTextBox.AppendText(t.ToString() + "\n");
                infoTextBox.AppendText("Suchi converter now ready.\n");
            }

            wbDocLoaded = true;
        }

        public string GetGoogleTranslation(string text, string langpair)
        {

            string request = "http://scriptconv.googlelabs.com/?tu=" + text + "&ln=" + langpair;

            HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(request);

            myReq.ContentType = "text/html; charset=UTF-8";

            HttpWebResponse myResponse = (HttpWebResponse) myReq.GetResponse();

            StreamReader sr = new StreamReader(myResponse.GetResponseStream());

            //string currentEncoding = sr.CurrentEncoding.EncodingName + " "+sr.CurrentEncoding.CodePage;

            //currentEncoding = Unicode (UTF-8) 65001, which is as expected


            string textResponse = sr.ReadToEnd();

            //process textResponse, and return chinese translation

            //get debugging information
            //string contentEncoding = myResponse.ContentEncoding;

            //contentEncoding = ""
            //string charSet = myResponse.CharacterSet;

            //charset = ""
            //string type = myResponse.ContentType;

            int start = textResponse.IndexOf("name=\"tu\"") + 10;
            int end = textResponse.IndexOf("<", start);
            if (!(start < end))
                throw new Exception("Whoops ... bad response from Google!");
            string trans = textResponse.Substring(start, end - start);

            return trans;
        }

        void gotoLine(StreamReader sr, String str)
        {
            String strLine;
            do
            {
                strLine = sr.ReadLine();
            }
            while (!strLine.Contains(str));
        }

        void gotoLine(ParseHTML parse, String str)
        {
            String strLine = "";
            do
            {
                char ch = parse.Parse();
                if (ch == 0)
                    strLine = "";
                else
                    strLine += ch;
            }
            while (!strLine.Contains(str));
        }

        private void writeOutFile(String filepath, String fileout)
        {
            StreamReader sr = new StreamReader(filepath, Encoding.Default);
            StreamWriter sw = new StreamWriter(fileout, false, Encoding.Unicode);
            String strLine = "";
            int c = 0;


            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.Contains("Øekad"))
                {
                    //Read the entries
                    String row = "*+*";

                    //skip lines until the 1st entry
                    do
                    {
                        if (strLine != null && (strLine.Contains("Øekad") || strLine.Contains("dh la[;")))
                        {
                            while ((strLine = sr.ReadLine()).Trim().Equals("")) ;
                            if (strLine.Trim().Equals("1"))
                                break;
                        }
                        else
                            strLine = sr.ReadLine();



                    } while ((strLine != null));

                    if (strLine == null)
                        break;

                    //Read the entries
                    //String row = "";
                    do
                    {
                        if (strLine.Trim().Length <= 1)
                        {
                            int tmp;
                            if (strLine.Trim().Equals("â"))
                                strLine = "";
                            else if (Int32.TryParse(strLine.Trim(), out tmp))
                            {
                                strLine = "\r\n" + strLine;
                            }

                        }
                        else
                        {
                            if (!row.Equals(""))
                                strLine = "\r\n" + strLine;
                        }
                        row += strLine;

                        strLine = sr.ReadLine();

                    } while (!(strLine.Contains("okMZ dk ;ksx") || strLine.Contains("okMZ la[") || strLine.Contains("Page")));

                    //TODO: See if we can "safely" add a check for the case when the final votes tally
                    //appears after okMZ dk ;ksx
                    if (strLine.Contains("okMZ dk ;ksx"))
                    {
                        String str1 = sr.ReadLine();
                        int tmp1;
                        if (Int32.TryParse(str1, out tmp1))
                        {
                            int tmp2;
                            String str2 = sr.ReadLine();
                            if (Int32.TryParse(str2, out tmp2))
                            {
                                row += "\r\n" + str1;
                            }
                        }

                    }

                    row = convertToUnicode(row);
                    Console.WriteLine(row);
                    row += "\r\n*-*\r\n\r\n";
                    sw.WriteLine(row);
                    c++;
                }
            }

            sw.Close();
            sr.Close();
        }

        private int writeToExcel(String buffer, Excel.Worksheet xlWorkSheet, Excel.Worksheet xlWorkSheet1, int row, int page)
        {
            String buf = ed_pre.fix(buffer); 
            String r1 = "";
            String r2 = "";
            bool doneTranslate = false;
            while (!doneTranslate)
            {
                try
                {
                    r1 = GetGoogleTranslation(buf, "en");
                    r2 = Translator.Translate(buf, Language.Hindi, Language.English);
                    doneTranslate = true;
                }
                catch (Exception ge)
                {
                    infoTextBox.AppendText("Translation failed, sleeping for 30 seconds ...");
                    System.Threading.Thread.Sleep(30000);
                }
            }
            
            
            r1 = ed_post.fix(r1);
            r2 = ed_post.fix(r2);

            //TODO: Check on the missing symbol error with Translation

            string[] rowStr = r1.Split(new String[1] {"$end$"}, StringSplitOptions.RemoveEmptyEntries);
            string[] rowStr1 = r2.Split(new string[] { "end $", "$ end" }, StringSplitOptions.RemoveEmptyEntries);
            int i1 = 0;
            for ( int i = 0; i < rowStr.Length; i++ )
            {
                String r = rowStr[i];
                String r_1 = rowStr1[i1];

                /*String[] r_11 = r_1.Split(new String[1] { "$ end" }, StringSplitOptions.RemoveEmptyEntries);

                if (r_11.Length > 1)
                {
                    String[] tmp = r_11[1].Split(new String[1] { "$" }, StringSplitOptions.RemoveEmptyEntries);
                    if (tmp.Length > 1)
                    {
                        r_11 += tmp[0];
                        r_1 = r_11;
                        rowStr1.Aggregate(
                    }
                }*/

                //TODO: verify the 2 statements below actually work
                r_1 = r_1.Replace('$', (char)0);
                r_1 = r_1.Replace("end", "");
                if (r.Length > 1)
                {
                    //r_1 might be a simple blank space
                    //String splitting fails occasionally
                    //Appears to be a .NET bug
                    while (r_1.Length <= 1)
                    {
                        i1++;
                        r_1 = rowStr1[i1];
                    }

                    string[] cellStr = r.Split(new String[1] {"||"}, StringSplitOptions.RemoveEmptyEntries);
                    string[] cellStr1 = r_1.Split(new string[] { "| |", "||" }, StringSplitOptions.RemoveEmptyEntries);
                    int j = 1;
                    xlWorkSheet.Cells[row, j] = page + "";
                    xlWorkSheet1.Cells[row, j] = page + "";
                    j++;
                    for (int c = 0; c < cellStr.Length && j <= 11; c++)
                    {
                        if (cellStr[c].Equals("*-*"))
                            break;

                        if (!cellStr[c].Equals(""))
                        {
                            xlWorkSheet.Cells[row, j] = cellStr[c];
                            xlWorkSheet1.Cells[row, j] = cellStr1[c];
                            j++;
                        }
                    }
                    i1++;
                    row++;
                }
            }

            infoTextBox.AppendText("Now at excel row: " + row + "... \n");

            return row;
        }
    }
}
